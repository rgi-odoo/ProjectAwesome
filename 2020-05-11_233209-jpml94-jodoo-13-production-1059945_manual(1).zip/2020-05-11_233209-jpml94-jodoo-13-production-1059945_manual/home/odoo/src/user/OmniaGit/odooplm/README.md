# odooplm

This is the develompent repository of odoo plm starting from version v11 of odoo

This series of modules increase the capability of odoo in the plm field.
for any issues you may send an e-mail to info@omniasolutions.eu

The old repository for the version before 11 remain at the following link:
https://sourceforge.net/projects/openerpplm/
at the same address you can also find more information regarding the solution

